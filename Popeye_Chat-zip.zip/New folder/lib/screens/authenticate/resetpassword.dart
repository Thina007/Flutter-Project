import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:sample/screens/authenticate/sign_in.dart';
import 'package:sample/shared/constants.dart';

class ResetPassword extends StatefulWidget {
  const ResetPassword({Key? key}) : super(key: key);

  @override
  _ResetPasswordState createState() => _ResetPasswordState();
}

class _ResetPasswordState extends State<ResetPassword> {
  String? useremail;
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.brown[100],
      appBar: AppBar(
        title: Text('ResetPassword'),
      ),
      body: Form(
        key: _formKey,
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 50.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(
                height: 100,
              ),
              TextFormField(
                decoration:
                    textInputDecoration.copyWith(labelText: 'Enter Your Email'),
                validator: (val) => val!.isEmpty ? 'Enter an Email' : null,
                onChanged: (val) {
                  setState(() {
                    useremail = val;
                  });
                },
              ),
              SizedBox(
                height: 30,
              ),
              RaisedButton(
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    setState(() {});
                  }
                  Widget continueButton = TextButton(
                    child: Text("Ok"),
                    onPressed: () async {
                      await FirebaseAuth.instance
                          .sendPasswordResetEmail(email: useremail!)
                          .then((value) => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => SignIn())));
                    },
                  );

                  // set up the AlertDialog
                  AlertDialog alert = AlertDialog(
                    title: Text("Send password reset email successfully"),
                    actions: [
                      continueButton,
                    ],
                  );

                  // show the dialog
                  useremail == null
                      ? print('Error')
                      : showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return alert;
                          },
                        );

                  // await FirebaseAuth.instance
                  //     .sendPasswordResetEmail(email: useremail!)
                  //     .then((value) => Navigator.push(context,
                  //         MaterialPageRoute(builder: (context) => SignIn())));
                },
                child: Text(
                  'Sign in',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold),
                ),
                color: Colors.pink,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
