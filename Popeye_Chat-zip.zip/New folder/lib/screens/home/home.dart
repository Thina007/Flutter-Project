import 'package:flutter/material.dart';
import 'package:sample/models/user.dart';
import 'package:sample/screens/home/profile.dart';
import 'package:sample/screens/home/profile_steam.dart';
import 'package:sample/screens/home/setting_form.dart';
import 'package:sample/services/auth.dart';
import 'package:provider/provider.dart';
import 'package:sample/services/database.dart';
import 'package:sample/screens/home/brew_list.dart';
import 'package:sample/models/brew.dart';
//https://flutter.dev/custom-fonts/#from-packages

class Home extends StatefulWidget {
  //String userid = AuthService().inputData();

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    //final userr = Provider.of<UserData?>(context);
    //print('Emailllll  :' + userr!.email.toString());

    final user = Provider.of<MyUser?>(context);
    //print('uid :' + user!.uid.toString());
    void _showsettingpanel() {
      showModalBottomSheet(
          context: context,
          builder: (context) {
            return Container(
              padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
              child: SettingForm(),
            );
          });
    }

    void _profileedite() {
      Navigator.push(context, MaterialPageRoute(
        builder: (context) {
          return ProfileStream();
        },
      ));
    }

    final AuthService _auth = AuthService();
    return StreamProvider<List<Brew>?>.value(
      value: DatabaseService().brews,
      initialData: null,
      child: Scaffold(
          backgroundColor: Colors.grey[100],
          appBar: AppBar(
            backwardsCompatibility: false,
            title: Text('P O P E Y E'),
            backgroundColor: Colors.grey[400],
            titleTextStyle: TextStyle(
                fontWeight: FontWeight.bold,
                //fontStyle: FontStyle.italic,
                color: Colors.blue[900],
                fontSize: 18),
            actions: [
              IconButton(
                onPressed: () async {
                  // set up the buttons
                  Widget cancelButton = TextButton(
                    child: Text("Cancel"),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  );
                  Widget continueButton = TextButton(
                    child: Text("Sign out"),
                    onPressed: () async {
                      await _auth.signOut();
                      Navigator.pop(context);
                    },
                  );

                  // set up the AlertDialog
                  AlertDialog alert = AlertDialog(
                    title:
                        Text("Are you sure you want to sign out your account?"),
                    content: Text(
                        "This action will temporary sign out your account"),
                    actions: [
                      cancelButton,
                      continueButton,
                    ],
                  );

                  // show the dialog
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return alert;
                    },
                  );
                },
                //await _auth.signOut();

                icon: Icon(Icons.power_settings_new),
                color: Colors.blue,
                //label: Text('logout'),
              ),
              IconButton(
                  color: Colors.blue,
                  onPressed: () => _profileedite(),
                  icon: Icon(
                    Icons.settings,
                  ))
            ],
          ),
          body: Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: NetworkImage(
                    'https://media.istockphoto.com/photos/green-background-3d-render-picture-id1226478926?b=1&k=20&m=1226478926&s=170667a&w=0&h=JnDdZVzHtMBfq5ZYQBevaTDCvbDRS2ZS5iGeaJKXBqA='),
                fit: BoxFit.cover,
              ),
            ),
            child: BrewList(),
          ),
          floatingActionButton:
              Column(mainAxisAlignment: MainAxisAlignment.end, children: [
            FloatingActionButton(
              onPressed: () => _showsettingpanel(),
              child: Icon(Icons.message),
              backgroundColor: Colors.pink,
              mini: false,
              highlightElevation: 20.0,
              shape: BeveledRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(16.0))),
            ),
            SizedBox(
              height: 10,
            ),
            FloatingActionButton(
              onPressed: () async {
                // set up the buttons
                Widget cancelButton = TextButton(
                  child: Text("Cancel"),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                );
                Widget continueButton = TextButton(
                  child: Text("Delete"),
                  onPressed: () async {
                    await DatabaseService(uid: user!.uid).deletemessage();
                    Navigator.pop(context);
                  },
                );

                // set up the AlertDialog
                AlertDialog alert = AlertDialog(
                  title: Text("Are you sure you want to delete the chat?"),
                  content:
                      Text("This action will permanently delete all your chat"),
                  actions: [
                    cancelButton,
                    continueButton,
                  ],
                );

                // show the dialog
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return alert;
                  },
                );
              },
              child: Icon(Icons.delete),
              backgroundColor: Colors.red,
              mini: false,
              highlightElevation: 20.0,
              shape: BeveledRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(16.0))),
            ),
          ])),
    );
  }
}
//flutter build apk --releaseflu