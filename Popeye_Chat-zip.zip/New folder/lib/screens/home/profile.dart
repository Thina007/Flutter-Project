import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:sample/models/user.dart';
import 'package:sample/screens/authenticate/resetpassword.dart';
import 'package:sample/services/auth.dart';
import 'package:sample/services/database.dart';
import 'package:sample/services/database.dart';
import 'package:sample/services/storage.dart';
import 'package:sample/shared/loading.dart';

class Profile extends StatefulWidget {
  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  final AuthService _auth = AuthService();
  PickedFile? imageFile;
  String? msg;

  putFile(ImageSource source, String? uid) async {
    final file = await ImagePicker.platform.pickImage(source: source);
    imageFile = file;
    msg = await StorageService().uploadImage(imageFile!, uid!);
    setState(() {
      print('Message: ' + msg!);
    });
  }

  @override
  Widget build(BuildContext context) {
    final _formKey = GlobalKey<FormState>();
    final userr = Provider.of<MyUser?>(context);
    String? userpassword;

    void _changePassword(String password) async {
      //Create an instance of the current user.
      final FirebaseAuth _auth = FirebaseAuth.instance;
      final User user = _auth.currentUser!;
      //Pass in the password to updatePassword.
      user.updatePassword(password).then((_) {
        print("Successfully changed password");
      }).catchError((error) {
        print("Password can't be changed" + error.toString());
        //This might happen, when the wrong password is in, the user isn't found, or if the user hasn't logged in recently.
      });
    }

    Widget bottomsheet() {
      return Container(
        width: MediaQuery.of(context).size.width,
        height: 120,
        margin: EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 20,
        ),
        child: Column(
          children: [
            Text(
              'Choose Profile photo',
              style: TextStyle(fontSize: 20.0),
            ),
            SizedBox(
              height: 20.0,
            ),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              FlatButton.icon(
                onPressed: () async {
                  await putFile(ImageSource.camera, userr!.uid);
                  Navigator.pop(context);
                },
                icon: Icon(Icons.camera),
                label: Text('Camera'),
              ),
              FlatButton.icon(
                onPressed: () async {
                  await putFile(ImageSource.gallery, userr!.uid);
                  Navigator.pop(context);
                },
                icon: Icon(Icons.image),
                label: Text('Gallery'),
              ),
            ]),
          ],
        ),
      );
    }

    final user = Provider.of<UserData?>(context);
    return user == null
        ? Loading()
        : Scaffold(
            appBar: AppBar(
              backgroundColor: Theme.of(context).scaffoldBackgroundColor,
              elevation: 1,
              leading: IconButton(
                icon: Icon(
                  Icons.arrow_back,
                  color: Colors.green,
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
              actions: [
                IconButton(
                  icon: Icon(
                    Icons.settings,
                    color: Colors.green,
                  ),
                  onPressed: () {
                    // Navigator.of(context).push(MaterialPageRoute(
                    //     builder: (BuildContext context) => SettingsPage()));
                  },
                ),
              ],
            ),
            body: Container(
              padding: EdgeInsets.only(left: 16, top: 25, right: 16),
              child: GestureDetector(
                onTap: () {
                  FocusScope.of(context).unfocus();
                },
                child: ListView(
                  children: [
                    Text(
                      "Edit Profile",
                      style:
                          TextStyle(fontSize: 25, fontWeight: FontWeight.w500),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Center(
                      child: Stack(
                        children: [
                          Container(
                              width: 130,
                              height: 130,
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      width: 4,
                                      color: Theme.of(context)
                                          .scaffoldBackgroundColor),
                                  boxShadow: [
                                    BoxShadow(
                                        spreadRadius: 2,
                                        blurRadius: 10,
                                        color: Colors.black.withOpacity(0.1),
                                        offset: Offset(0, 10))
                                  ],
                                  shape: BoxShape.circle,
                                  image: DecorationImage(
                                      fit: BoxFit.cover,
                                      image: user.strength == ''
                                          ? AssetImage('assets/profile.png')
                                          : NetworkImage((user.strength)!)
                                              as ImageProvider))),
                          Positioned(
                              bottom: 0,
                              right: 0,
                              child: Container(
                                height: 40,
                                width: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    width: 4,
                                    color: Theme.of(context)
                                        .scaffoldBackgroundColor,
                                  ),
                                  color: Colors.green,
                                ),
                                child: IconButton(
                                  onPressed: () {
                                    showModalBottomSheet(
                                        context: context,
                                        builder: ((builder) => bottomsheet()));
                                  },
                                  icon: Icon(Icons.edit),
                                  color: Colors.white,
                                ),
                              )),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 35,
                    ),
                    buildTextField("Full Name", user.name.toString(), false),
                    buildTextFieldd("E-mail", user.email.toString(), false),
                    //buildTextFielddd("Change Password", user.password.toString(), true),
                    //buildTextField("Location", "TLV, Israel", false),
                    RaisedButton(
                      color: Colors.blue,
                      padding: EdgeInsets.symmetric(horizontal: 50),
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                      onPressed: () async {
                        // set up the buttons
                        Widget cancelButton = TextButton(
                          child: Text("Cancel"),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                        );
                        Widget continueButton = TextButton(
                          child: Text("Change"),
                          onPressed: () async {
                            _changePassword(userpassword!);
                            Navigator.pop(context);
                          },
                        );

                        // set up the AlertDialog
                        AlertDialog alert = AlertDialog(
                          title: Text(
                              "Are you sure you want to change your password?"),
                          content: new Row(
                            children: <Widget>[
                              new Expanded(
                                child: new TextField(
                                  autofocus: true,
                                  decoration: new InputDecoration(
                                    labelText: 'Change password',
                                  ),
                                  onChanged: (val) {
                                    setState(() {
                                      userpassword = val;
                                      print('userpassword: ' + userpassword!);
                                    });
                                  },
                                ),
                              )
                            ],
                          ),
                          actions: [
                            cancelButton,
                            continueButton,
                          ],
                        );

                        // show the dialog
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return alert;
                          },
                        );
                      },
                      child: Text(
                        'Change password',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(
                          builder: (context) {
                            return ResetPassword();
                          },
                        ));
                      },
                      child: Text(
                        '                                                                       Reset Password?',
                        style: TextStyle(
                          color: Colors.blue,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 35,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        OutlineButton(
                          padding: EdgeInsets.symmetric(horizontal: 50),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20)),
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text("CANCEL",
                              style: TextStyle(
                                  fontSize: 14,
                                  letterSpacing: 2.2,
                                  color: Colors.black)),
                        ),
                        RaisedButton(
                          onPressed: () async {
                            //await _auth.changePassword('thina', 'thinagaran');
                            // if (_formKey.currentState!.validate()) {
                            //   setState(() {
                            //     Loading();
                            //   });
                            // }
                            dynamic result =
                                await DatabaseService(uid: user.uid)
                                    .updateName(name!);
                            if (result == null) {
                              setState(() {
                                print('Please Supply a valid Email !!!');
                              });
                            }
                            Navigator.pop(context);
                          },
                          color: Colors.green,
                          padding: EdgeInsets.symmetric(horizontal: 50),
                          elevation: 2,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20)),
                          child: Text(
                            "SAVE",
                            style: TextStyle(
                                fontSize: 14,
                                letterSpacing: 2.2,
                                color: Colors.white),
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
            ),
          );
  }

  String? name;
  String? email;
  String? password;

  Widget buildTextField(
      String labelText, String placeholder, bool isPasswordTextField) {
    return Padding(
        padding: const EdgeInsets.only(bottom: 35.0),
        child: TextFormField(
            decoration: InputDecoration(
                contentPadding: EdgeInsets.only(bottom: 3),
                labelText: labelText,
                floatingLabelBehavior: FloatingLabelBehavior.always,
                hintText: placeholder,
                hintStyle: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                )),
            //validator: (val) => val!.isEmpty ? 'Enter Your Name' : null,
            onChanged: (val) {
              setState(() {
                name = val == '' ? placeholder : val;
                print("Name:  " + name!);
              });
            }));
  }

  Widget buildTextFieldd(
      String labelText, String placeholder, bool isPasswordTextField) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 35.0),
      child: TextField(
        //obscureText: isPasswordTextField ? showPassword : false,
        decoration: InputDecoration(
            contentPadding: EdgeInsets.only(bottom: 3),
            labelText: labelText,
            enabled: false,
            floatingLabelBehavior: FloatingLabelBehavior.always,
            hintText: placeholder,
            hintStyle: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            )),
      ),
    );
  }

  bool showPassword = true;
  Widget buildTextFielddd(
      String labelText, String placeholder, bool isPasswordTextField) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 35.0),
      child: TextField(
          obscureText: isPasswordTextField ? showPassword : false,
          decoration: InputDecoration(
              suffixIcon: isPasswordTextField
                  ? IconButton(
                      onPressed: () {
                        setState(() {
                          showPassword = !showPassword;
                        });
                      },
                      icon: Icon(
                        Icons.remove_red_eye,
                        color: Colors.grey,
                      ),
                    )
                  : null,
              contentPadding: EdgeInsets.only(bottom: 3),
              labelText: labelText,
              floatingLabelBehavior: FloatingLabelBehavior.always,
              //hintText: 'new password',
              hintStyle: TextStyle(
                fontSize: 12,
                //fontWeight: FontWeight.bold,
                color: Colors.black,
              )),
          onChanged: (val) {
            setState(() {
              password = val == '' ? placeholder : val;
              print("password  " + password!);
            });
          }),
    );
  }
}
