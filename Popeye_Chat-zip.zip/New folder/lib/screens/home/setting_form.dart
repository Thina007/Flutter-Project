import 'package:flutter/material.dart';
import 'package:sample/models/user.dart';
import 'package:sample/services/database.dart';
import 'package:sample/shared/constants.dart';
import 'package:provider/provider.dart';
import 'package:sample/shared/loading.dart';

class SettingForm extends StatefulWidget {
  @override
  _SettingFormState createState() => _SettingFormState();
}

class _SettingFormState extends State<SettingForm> {
  final _keyform = GlobalKey<FormState>();

  //form value

  String? _currentSugar;
  @override
  Widget build(BuildContext context) {
    final user = Provider.of<MyUser?>(context);
    //print('user id: ' + user!.uid.toString());
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return SingleChildScrollView(
      padding: EdgeInsets.only(bottom: bottom),
      reverse: true,
      child: StreamBuilder<UserData>(
          stream: DatabaseService(uid: (user!.uid)).userData,
          builder: (context, snapshot) {
            print(snapshot.data);
            if (snapshot.data != null) {
              UserData? userData = snapshot.data;
              print(userData);
              return SingleChildScrollView(
                child: Form(
                    key: _keyform,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 280.0,
                          //height: 320.0,
                          child: TextFormField(
                            maxLines: null,
                            decoration: textInputDecorationn,

                            //enabled: false,
                            validator: (val) => val!.isEmpty
                                ? 'Please type message here!! !!!'
                                : null,
                            onChanged: (val) {
                              setState(() {
                                _currentSugar = val;
                              });
                            },
                          ),
                        ),
                        SizedBox(
                          width: 20,
                        ),
                        IconButton(
                            onPressed: () async {
                              if (_keyform.currentState!.validate()) {
                                await DatabaseService(uid: user.uid)
                                    .updatemessage(_currentSugar.toString());
                                Navigator.pop(context);
                              }
                            },
                            icon: Icon(Icons.send)),
                      ],
                    )),
              );
            } else {
              return Loading();
            }
          }),
    );
  }
}
