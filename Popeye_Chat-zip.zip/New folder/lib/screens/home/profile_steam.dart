import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sample/models/user.dart';
import 'package:sample/screens/home/profile.dart';
import 'package:sample/services/database.dart';
import 'package:sample/shared/loading.dart';

class ProfileStream extends StatefulWidget {
  @override
  _ProfileStreamState createState() => _ProfileStreamState();
}

class _ProfileStreamState extends State<ProfileStream> {
  @override
  Widget build(BuildContext context) {
    final user = Provider.of<MyUser?>(context);
    //print('profile: ' + user!.uid.toString());

    return user == null
        ? Loading()
        : StreamProvider<UserData?>.value(
            catchError: (User, UserData) => null,
            value: DatabaseService(uid: (user.uid)).userData,
            initialData: null,
            child: Profile(),
          );
  }
}
