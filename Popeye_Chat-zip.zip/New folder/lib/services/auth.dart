import 'dart:ffi';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:sample/models/user.dart';
import 'package:sample/services/database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String inputData() {
    final User user = _auth.currentUser!;
    final uid = user.uid;
    return uid;
  }

// Create user based on FirebaseUser
  MyUser? _userfromFirebaseUser(User user) {
    return MyUser(uid: user.uid);
  }

//auth change user stream
  Stream<MyUser?> get user {
    return _auth
        .authStateChanges()
        .map((User? user) => _userfromFirebaseUser(user!));
  }

// sign in anan
  Future signInAnon() async {
    try {
      UserCredential result = await _auth.signInAnonymously();
      User user = result.user!;
      return _userfromFirebaseUser(user);
    } on FirebaseAuthException catch (e) {
      print(e.code);
      return null;
    }
  }

//Sign in with email and password:

  Future signInwithemailandpassword(String email, String password) async {
    try {
      UserCredential result = await _auth.signInWithEmailAndPassword(
          email: email, password: password);
      User user = result.user!;
      return _userfromFirebaseUser(user);
    } catch (e) {
      print(e.toString());
    }
  }

  //change password


  //Register with email and password:
  Future registerwithemailandpassword(
      String username, String email, String password) async {
    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
      User user = result.user!;
      await DatabaseService(uid: user.uid)
          .updateUserData('', username, '', email, password);
      return _userfromFirebaseUser(user);
    } catch (e) {
      print(e.toString());
    }
  }

// sign out
  Future signOut() async {
    try {
      return await _auth.signOut();
    } catch (e) {
      print(e.toString());
      return null;
    }
  }
}
