import 'package:flutter/material.dart';
import 'package:sample/models/user.dart';
import 'package:sample/screens/home/setting_form.dart';
import 'package:sample/services/auth.dart';
import 'package:provider/provider.dart';
import 'package:sample/services/database.dart';
import 'package:sample/screens/home/brew_list.dart';
import 'package:sample/models/brew.dart';

class Home extends StatelessWidget {
  String userid = AuthService().inputData();

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<MyUser?>(context);
    //print('uid :' + user!.uid.toString());
    void _showsettingpanel() {
      showModalBottomSheet(
          context: context,
          builder: (context) {
            return Container(
              padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
              child: SettingForm(),
            );
          });
    }

    final AuthService _auth = AuthService();
    return StreamProvider<List<Brew>?>.value(
      value: DatabaseService().brews,
      initialData: null,
      child: Scaffold(
        backgroundColor: Colors.grey[100],
        appBar: AppBar(
          title: Text('Home Screen'),
          backgroundColor: Colors.grey[400],
          actions: [
            FlatButton.icon(
              onPressed: () async {
                await _auth.signOut();
              },
              icon: Icon(Icons.person),
              label: Text('logout'),
            ),
            // FlatButton.icon(
            //   onPressed: () => _showsettingpanel(),
            //   icon: Icon(Icons.settings),
            //   label: Text('Setting'),
            // )
          ],
        ),
        body: Container(
            decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage('assets/coffee_bg.png'),
                    fit: BoxFit.cover)),
            child: BrewList()),
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            if (user!.uid == userid) {
              _showsettingpanel();
            }
          },
          backgroundColor: Colors.pink,
          child: Icon(Icons.add),
        ),
      ),
    );
  }
}
  
