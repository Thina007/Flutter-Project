import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sample/models/brew.dart';
import 'package:sample/models/user.dart';
import 'package:sample/screens/home/setting_form.dart';
import 'package:sample/services/auth.dart';
import 'package:sample/services/database.dart';

class BrewTile extends StatelessWidget {
  //String userid = AuthService().inputData();

  final Brew? brew;
  BrewTile({this.brew});
  @override
  Widget build(BuildContext context) {
    //print(userid);
    // final user = Provider.of<MyUser?>(context);
    // //print('uid :' + user!.uid.toString());
    // void _showsettingpanel() {
    //   showModalBottomSheet(
    //       context: context,
    //       builder: (context) {
    //         return Container(
    //           padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
    //           child: SettingForm(),
    //         );
    //       });
    // }

    return Padding(
        padding: EdgeInsets.only(top: 8.0),
        child: Card(
          margin: EdgeInsets.fromLTRB(20, 6, 20.0, 0.0),
          child: ListTile(
            //   onTap: () {
            //   if (user!.uid == userid) {
            //     _showsettingpanel();
            //   }
            // },
            leading: CircleAvatar(
              radius: 25,
              backgroundColor: Colors.brown[(brew!.strength)!],
              backgroundImage: AssetImage('assets/coffee_icon.png'),
            ),
            title: Text((brew!.name)!),
            subtitle: Text('Takes ${(brew!.sugars)!} sugar(s)'),
          ),
        ));
  }
}
